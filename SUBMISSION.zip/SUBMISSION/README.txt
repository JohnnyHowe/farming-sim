A private repo for SENG201 farm sim project
arb142
joh29

java version "13.0.2"
As UI was built in IntelliJ, must be build through IntelliJ IDE.
See Report for more details.

Run by executing:
arb142_joh29_FarmingSimulator.jar
in same folder as this readme.