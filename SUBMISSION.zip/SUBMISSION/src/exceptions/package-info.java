/**
 * Custom exceptions created for Farm Simulator game
 * 
 * @author Alex Burling (arb142)
 * @version 1.0
 */
package exceptions;